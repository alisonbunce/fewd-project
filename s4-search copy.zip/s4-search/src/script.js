document
  .getElementById("search-form")
  .addEventListener("submit", function onSubmit(e) {
    e.preventDefault();
    let inputVal = document.getElementById("search-term").value;
    console.log(inputVal)
      if (inputVal === 'data for daily op use') {
        document.getElementById('s4-results').innerHTML = "yes"
        console.log('yes')
      } else if (inputVal === 'data creation') {
        document.getElementById('s4-results').innerHTML = "yes"
        console.log('yes')
      } else if (inputVal === 'reference data management'){
        document.getElementById('s4-results').innerHTML = "yes"
        console.log('yes')
      } else if (inputVal === 'find a tableau dashboard'){
        document.getElementById('s4-results').innerHTML = "no"
        console.log('no')
      } else {
        console.log('does not exist in S4')
      }
    });
